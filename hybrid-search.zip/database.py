import sqlite3
import os
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "policies.db")


def init_db():
    """Create tables and seed sample data"""
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("DROP TABLE IF EXISTS policies")

    cursor.execute("""
        CREATE TABLE policies (
            policy_id TEXT PRIMARY KEY,
            policy_name TEXT NOT NULL,
            category TEXT NOT NULL,
            effective_date TEXT,
            status TEXT,
            description TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    sample_policies = [
        (
            "POL001",
            "Maternity Leave Policy",
            "HR",
            "2023-01-15",
            "Active",
            "Eligible female employees are entitled to 6 months paid maternity leave. Requires 1 year service.",
        ),
        (
            "POL002",
            "Cybersecurity Data Protection",
            "IT",
            "2023-06-20",
            "Active",
            "All employee data must be encrypted. Passwords must be 16+ characters. Annual training mandatory.",
        ),
        (
            "POL003",
            "Remote Work Policy",
            "HR",
            "2023-03-10",
            "Active",
            "Employees can work remotely up to 3 days per week. Requires manager approval.",
        ),
        (
            "POL004",
            "Data Encryption Standards",
            "IT",
            "2023-08-01",
            "Active",
            "AES-256 encryption required for all sensitive documents. TLS 1.3 for data in transit.",
        ),
        (
            "POL005",
            "Leave & Attendance",
            "HR",
            "2022-12-01",
            "Active",
            "Annual leave: 20 days. Sick leave: 10 days. Compassionate: 5 days per year.",
        ),
        (
            "POL006",
            "Code of Conduct",
            "General",
            "2023-02-28",
            "Active",
            "All employees must adhere to ethical guidelines. Zero tolerance for discrimination and harassment.",
        ),
    ]

    cursor.executemany(
        """
        INSERT INTO policies 
        (policy_id, policy_name, category, effective_date, status, description)
        VALUES (?, ?, ?, ?, ?, ?)
    """,
        sample_policies,
    )

    conn.commit()
    conn.close()
    print("Database initialized!")


def search_policies(query, category=None, status="Active", date_from=None):
    """Search policies by keyword"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    sql = "SELECT * FROM policies WHERE 1=1"
    params = []

    if query:
        sql += " AND (policy_name LIKE ? OR description LIKE ?)"
        keyword = f"%{query}%"
        params.extend([keyword, keyword])

    if category:
        sql += " AND category = ?"
        params.append(category)

    if status:
        sql += " AND status = ?"
        params.append(status)

    if date_from:
        sql += " AND effective_date >= ?"
        params.append(date_from)

    cursor.execute(sql, params)
    results = cursor.fetchall()
    conn.close()

    return results


def get_categories():
    """Get all unique categories"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT DISTINCT category FROM policies")
    categories = [row[0] for row in cursor.fetchall()]
    conn.close()
    return categories


if __name__ == "__main__":
    init_db()
