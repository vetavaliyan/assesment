from flask import Flask, request, jsonify
from flask_cors import CORS
from search_engine import search_engine
from database import init_db, get_categories
import os

app = Flask(__name__)
CORS(app)


@app.before_request
def startup():
    if not os.path.exists(
        os.path.join(os.path.dirname(__file__), "..", "data", "policies.db")
    ):
        init_db()


@app.route("/")
def home():
    return jsonify({"message": "Hybrid Search API ready!"})


@app.route("/api/search", methods=["POST"])
def search():
    """POST /api/search"""
    try:
        data = request.get_json()
        query = data.get("query", "").strip()
        category = data.get("category")
        status = data.get("status", "Active")
        date_from = data.get("date_from")
        top_k = int(data.get("top_k", 10))

        if not query:
            return jsonify({"error": "Query cannot be empty"}), 400

        results = search_engine.search(
            query=query,
            category=category,
            status=status,
            date_from=date_from,
            top_k=top_k,
        )

        return jsonify(
            {"query": query, "result_count": len(results), "results": results}
        )

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/categories", methods=["GET"])
def categories():
    """Get all policy categories"""
    try:
        cats = get_categories()
        return jsonify({"categories": cats})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "healthy"}), 200


if __name__ == "__main__":
    app.run(debug=True, port=5000)
