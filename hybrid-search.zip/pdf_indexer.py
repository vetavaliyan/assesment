import os
import re
import pdfplumber
from pathlib import Path

SAMPLE_POLICIES_DIR = os.path.join(os.path.dirname(__file__), "sample_policies")


class PDFIndexer:
    def __init__(self, pdf_directory=None):
        self.pdf_dir = pdf_directory or SAMPLE_POLICIES_DIR
        self.documents = {}

    def load_and_index(self):
        """Load and extract text from PDF files using pdfplumber"""
        if not os.path.exists(self.pdf_dir):
            print(f"Directory {self.pdf_dir} does not exist")
            return

        for filename in os.listdir(self.pdf_dir):
            if filename.endswith(".pdf"):
                filepath = os.path.join(self.pdf_dir, filename)
                try:
                    with pdfplumber.open(filepath) as pdf:
                        full_text = ""
                        for page in pdf.pages:
                            text = page.extract_text()
                            if text:
                                full_text += text + "\n"

                    self.documents[filename] = {
                        "filepath": filepath,
                        "content": full_text,
                        "page_count": len(pdf.pages),
                        "sentences": self._extract_sentences(full_text),
                    }
                except Exception as e:
                    print(f"Error reading {filename}: {e}")

        print(f"Indexed {len(self.documents)} PDF documents")

    def _extract_sentences(self, text):
        """Split text into sentences"""
        sentences = re.split(r"[.!?]+", text)
        return [s.strip() for s in sentences if len(s.strip()) > 10]

    def search(self, query):
        """Search across all PDFs and return relevant snippets"""
        results = []
        query_lower = query.lower()

        for filename, doc in self.documents.items():
            matching_sentences = []

            for sentence in doc["sentences"]:
                if query_lower in sentence.lower():
                    matching_sentences.append(sentence)

            if matching_sentences:
                snippet = " ".join(matching_sentences[:3])[:200] + "..."

                match_count = sum(
                    1 for s in matching_sentences if query_lower in s.lower()
                )
                score = min(100, match_count * 25)

                results.append(
                    {
                        "source": "PDF",
                        "title": filename.replace(".pdf", "").replace("_", " ").title(),
                        "snippet": snippet,
                        "score": score,
                        "page": 1,
                        "filename": filename,
                        "page_count": doc.get("page_count", 1),
                    }
                )

        return results


indexer = PDFIndexer()

if __name__ == "__main__":
    indexer.load_and_index()
    results = indexer.search("maternity leave")
    for r in results:
        print(f"{r['title']}: {r['score']}% - {r['snippet'][:100]}")
