const API_URL = 'http://localhost:5000/api';

const queryInput = document.getElementById('query');
const searchBtn = document.getElementById('searchBtn');
const categorySelect = document.getElementById('category');
const statusSelect = document.getElementById('status');
const dateFromInput = document.getElementById('dateFrom');
const topkSelect = document.getElementById('topk');
const resultsContainer = document.getElementById('results');

searchBtn.addEventListener('click', performSearch);

queryInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') performSearch();
});

async function performSearch() {
    const query = queryInput.value.trim();
    
    if (!query) {
        resultsContainer.innerHTML = '<div class="no-results">Please enter a search query</div>';
        return;
    }

    resultsContainer.innerHTML = '<div class="loading">Searching...</div>';

    try {
        const response = await fetch(`${API_URL}/search`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                query: query,
                category: categorySelect.value || null,
                status: statusSelect.value,
                date_from: dateFromInput.value || null,
                top_k: parseInt(topkSelect.value)
            })
        });

        if (!response.ok) throw new Error('Search failed');

        const data = await response.json();
        displayResults(data);
    } catch (error) {
        resultsContainer.innerHTML = `<div class="no-results">Error: ${error.message}</div>`;
    }
}

function displayResults(data) {
    if (!data.results || data.results.length === 0) {
        resultsContainer.innerHTML = '<div class="no-results">No results found. Try a different query.</div>';
        return;
    }

    let html = `<h2>${data.result_count} results for "${data.query}"</h2>`;

    data.results.forEach((result) => {
        const sourceClass = result.source === 'Database' ? 'source-database' : 'source-pdf';
        const meta = [];

        if (result.category) meta.push(`Category: ${result.category}`);
        if (result.effective_date) meta.push(`Effective: ${result.effective_date}`);
        if (result.page) meta.push(`Page: ${result.page}`);

        html += `
            <div class="result-item">
                <div class="result-header">
                    <div>
                        <div class="result-title">${escapeHtml(result.title)}</div>
                        <span class="result-source ${sourceClass}">${result.source}</span>
                    </div>
                    <div class="result-score">Score: ${result.score}%</div>
                </div>
                <p class="result-snippet">${escapeHtml(result.snippet)}</p>
                <div class="result-meta">${meta.join(' • ')}</div>
            </div>
        `;
    });

    resultsContainer.innerHTML = html;
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

window.addEventListener('load', async () => {
    try {
        const response = await fetch(`${API_URL}/categories`);
        const data = await response.json();
        
        data.categories.forEach(cat => {
            const option = document.createElement('option');
            option.value = cat;
            option.textContent = cat;
            categorySelect.appendChild(option);
        });
    } catch (error) {
        console.error('Failed to load categories:', error);
    }
});