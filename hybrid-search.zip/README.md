# Hybrid Policy Search System

A full-stack search engine combining structured (SQLite) and unstructured (PDF) data retrieval with relevance ranking.

## Quick Start

### Prerequisites
- Python 3.8+
- Windows/Mac/Linux

### Installation
1. Navigate to backend folder:
   ```bash
   cd hybrid-search/backend
   ```

2. Create and activate virtual environment:
   ```bash
   python -m venv venv
   venv\Scripts\activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Initialize database:
   ```bash
   python database.py
   ```

### Running the Application

1. Start the backend server (Terminal 1):
   ```bash
   python app.py
   ```
   Server runs on http://localhost:5000

2. Start the frontend (Terminal 2):
   ```bash
   cd ..\frontend
   python -m http.server 8000
   ```

3. Open browser:
   ```
   http://localhost:8000
   ```

## Architecture

- **Backend**: Flask API + SQLite DB + PDF Indexer
- **Frontend**: HTML/JS (no build step)
- **Search**: Hybrid ranking combining structured + unstructured results

## Key Features

- Full-text search on DB policies
- PDF snippet extraction
- Combined relevance scoring
- Category/Status/Date filters
- Top-K result selection

## Search API

### POST /api/search
```json
{
  "query": "maternity leave",
  "category": "HR",
  "status": "Active",
  "top_k": 10
}
```

### GET /api/categories
Returns available policy categories.

### GET /api/health
Returns API status.

## Project Structure
```
hybrid-search/
├── backend/
│   ├── app.py           # Flask server
│   ├── database.py      # SQLite setup
│   ├── pdf_indexer.py  # PDF text extraction
│   ├── search_engine.py # Hybrid search logic
│   ├── requirements.txt
│   └── sample_policies/ # Mock PDFs
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── app.js
├── data/
│   └── policies.db      # SQLite database
└── README.md
```

## Demo Queries
1. "maternity leave eligibility"
2. "cybersecurity encryption"
3. "remote work"
4. "leave"
5. "data protection"

## Time Spent
- Setup: 15 min
- DB: 30 min
- PDF Indexing: 45 min
- Search Logic: 1.5 hrs
- Backend API: 45 min
- Frontend: 1 hr
- Testing: 30 min
- **Total: ~6.5 hours**